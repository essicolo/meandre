"""Colonne verticale FIDÈLE Hydrotel — orchestrateur natif méandre (Phase A).

Chaîne, dans l'ordre EXACT d'Hydrotel (cf BV3C2::Calcule), les modules clonés et
validés un à un contre le C++ (hydrotel_clone/, Phase B) :

  forçage → split pluie/neige → FONTE NEIGE (degré-jour modifié)
         → GEL RANKINEN (profil de température → profondeur de gel)
         → ETP (McGuinness | Hydro-Québec | Penman-Monteith, au choix)
         → ETR par couche (CalculeEtr : sol nu Beer + transpiration racine×θ)
         → BILAN SOL BV3C2 (cascade saturation + split occupation fsa/fse/fsi,
           porte gel alimentée par RANKINEN)
         → MILIEU HUMIDE ISOLÉ (réservoir SWAT, optionnel par nœud)
         → production_surf/hypo/base (mm) = apport latéral au routage.

Tout est vectorisé sur les nœuds et différentiable. Les paramètres statiques par
nœud (texture, occupation, profondeurs, params neige/gel/wetland) sont posés une
fois via set_static() ; le sous-ensemble apprenable sera fourni par le NeRF en
Phase A (TODO ci-dessous). Ceci est le SQUELETTE : structure + forward complet
qui tourne ; le câblage NeRF/territorial et l'intégration dans model.py suivent.

DÉCISIONS Phase A (paramètres du constructeur) :
  - et_mode : formulation ETP (les 3 se valent ~ sous loss MODIS/GRACE).
  - use_frost : gel RANKINEN actif (amélioration méandre ; Hydrotel SLSO l'a OFF)
    → alimente la porte gel du sol (remplace le frost.py problématique).
"""
from __future__ import annotations
import os

from dataclasses import dataclass

import torch
import torch.nn as nn
from torch import Tensor

from meandre.utils.state import HydroState
from hydrotel_clone.snow import DegreJourModifie, init_ce, init_state as snow_init_state
from hydrotel_clone.frost import Rankinen, n_intervalles
from hydrotel_clone.et import hydro_quebec_etp, calcule_etr
from hydrotel_clone.mcguinness import mcguinness_etp
from hydrotel_clone.bv3c2 import BV3C2Clone, make_params, SOIL_TEXTURES
from hydrotel_clone.milieu_humide import init_wetland_geom, calcul_milieu_humide_isole
from meandre.vertical.aquifer import AquiferModule


def _interp1d(x, xp, fp):
    """Interpolation linéaire 1D torch reproduisant np.interp (xp croissant,
    clampé aux bords). x : tenseur 0-dim. Sans .item()/float() → pas de synchro
    GPU, compilable. Remplace le np.interp par pas de temps de la phénologie."""
    i = torch.searchsorted(xp, x.reshape(1), right=True).clamp(1, xp.numel() - 1)[0]
    x0, x1, y0, y1 = xp[i - 1], xp[i], fp[i - 1], fp[i]
    y = y0 + (y1 - y0) * (x - x0) / (x1 - x0)
    y = torch.where(x <= xp[0], fp[0], y)
    return torch.where(x >= xp[-1], fp[-1], y)


@dataclass
class HydrotelColumnState:
    """État interne de la colonne (plus riche que HydroState : la neige a 3
    classes avec cold content + eau retenue + albédo, le gel a un profil de
    température, le wetland un volume). theta1/2/3 et le couvert nival agrégé
    sont exposés pour la compatibilité avec HydroState/routage."""
    theta1: Tensor
    theta2: Tensor
    theta3: Tensor
    snow: dict                 # {classe: (stock,hauteur,chaleur,eau), 'albedo_'+classe, 'couvert_nival_mm'}
    frost_profile: Tensor      # (n_nodes, n_depth) température du sol
    wet_vol: Tensor            # (n_nodes,) volume milieu humide [m3]
    # États des cascades de Nash de l'hydrogramme de VERSANT (use_hillslope_uh) :
    # surface (uh_s1,uh_s2) + interflow (uh_s3,uh_s4). None si UH désactivé.
    uh_s1: Tensor | None = None
    uh_s2: Tensor | None = None
    uh_s3: Tensor | None = None
    uh_s4: Tensor | None = None

    def detach(self) -> "HydrotelColumnState":
        sn = {}
        for k, v in self.snow.items():
            sn[k] = tuple(t.detach() for t in v) if isinstance(v, tuple) else v.detach()
        _d = lambda t: t.detach() if t is not None else None
        return HydrotelColumnState(
            self.theta1.detach(), self.theta2.detach(), self.theta3.detach(),
            sn, self.frost_profile.detach(), self.wet_vol.detach(),
            _d(self.uh_s1), _d(self.uh_s2), _d(self.uh_s3), _d(self.uh_s4))


class HydrotelColumn(nn.Module):
    """Colonne verticale fidèle Hydrotel, un pas de temps journalier, vectorisée."""

    def __init__(self, et_mode: str = "mcguinness", use_frost: bool = True,
                 soil_n_substep: int = 48, frost_intervalle: float = 0.05,
                 frost_temp_ini: float = 4.0, frost_seuil: float = -0.5,
                 frost_fs: float = 2.35, frost_kt: float = 0.8,
                 frost_cs: float = 1.0e6, frost_cice: float = 4.0e6,
                 t_neige_seuil: float = 0.0, compile_soil: bool = False,
                 use_hillslope_uh: bool = False,
                 melt_mode: str = "degree_day", use_aquifer: bool = False,
                 use_hortonian: bool = False, frozen_gate_continuous: bool = False,
                 horton_precomputed: bool = False, spatial_melt: bool = False,
                 canopy_melt_lag: bool = False) -> None:
        super().__init__()
        soil_n_substep = int(os.environ.get("MEANDRE_NSUBSTEP", soil_n_substep))
        self.et_mode = str(et_mode)
        # Fonte SPATIALE : module les facteurs de fonte par classe avec le C_f du
        # NeRF (borné [0.5, 8], cible littérature 4.5 -> échelle neutre 1.0). Le
        # facteur de fonte devient un champ appris par nœud (sud-nord QC) au lieu
        # d'un scalaire global rustiné à la main (melt_factor_scale).
        self.spatial_melt = bool(spatial_melt)
        # Verrou de fonte par canopée appris plutôt qu'ancré (R56).
        self.canopy_melt_lag = bool(canopy_melt_lag)
        self.use_frost = bool(use_frost)
        self.use_hillslope_uh = bool(use_hillslope_uh)
        # Mode de fonte : "degree_day" (clone fidèle, indice radiation géométrique)
        # ou "eti" (Enhanced Temperature Index, radiation RÉELLE sw_in = canal FB).
        self.melt_mode = str(melt_mode)
        self.sw_channel = 6 if self.melt_mode == "eti" else None   # FB = canal 6 du forçage (cache -eb)
        # Hortonien sous-journalier (excès d'infiltration intensité-dépendant) : DT_eff au canal 6 (cache -intens).
        self.use_hortonian = bool(use_hortonian)
        self.storm_channel = 6 if self.use_hortonian else None
        # GARDE-FOU : les deux modes lisent le canal 6 mais attendent des caches
        # DIFFÉRENTS (FB en W/m² vs DT_eff en h). Les combiner lirait silencieusement
        # la mauvaise grandeur physique (revue 2026-07-01). Interdit tant que les
        # index ne sont pas séparés/validés contre les noms de variables du cache.
        if self.melt_mode == "eti" and self.use_hortonian:
            raise ValueError(
                "melt_mode='eti' et use_hortonian=True sont incompatibles : les deux "
                "lisent le canal de forçage 6 (FB vs DT_eff). Construire un cache "
                "combiné et séparer sw_channel/storm_channel avant de les cumuler.")
        # Aquifère restituant OPTIONNEL (meandre > Hydrotel) : route le drainage L3
        # (sinon baseflow instantané, recharge perdue cf. C++) dans un réservoir
        # linéaire qui SOUTIENT L'ÉTIAGE. Prélèvements souterrains agissent dans le
        # réservoir. k_gw par nœud (NeRF), contraint GRACE. OFF = clone Hydrotel fidèle.
        self.use_aquifer = bool(use_aquifer)
        self.aquifer = AquiferModule() if self.use_aquifer else None
        # variante puissance de la nappe (opt-in via gw_power_law = (q_ref, b))
        from meandre.vertical.aquifer import PowerLawAquifer
        self._pl_aquifer = PowerLawAquifer() if self.use_aquifer else None
        self.t_neige_seuil = t_neige_seuil   # seuil pluie/neige (split de phase, TODO: règle Hydrotel exacte)
        self.snow = DegreJourModifie(pas_de_temps=24)
        self.frost = Rankinen(frost_intervalle, frost_temp_ini, frost_seuil, frost_fs,
                              frost_kt, frost_cs, frost_cice, pas_de_temps=24)
        # compile_soil : torch.compile du sol, le seul poste qui compte. Le temps
        # mural est dominé par le pilotage CPU de la boucle de sous-pas (banc OUTV
        # 2026-08-19 : colonne 98 % du pas, routage 1,7 %), et fondre cette boucle
        # vaut x17,6 sur avant+arrière (157,5 -> 9,0 min/époque, 3412 nœuds).
        # Boucle de sous-pas static = résultats IDENTIQUES au mode break (vérifié).
        # La compilation DÉROULE la boucle de sous-pas : au-delà de ~64 itérations le
        # graphe explose (RecursionError dans l'inductor, mesuré à 300). On désactive
        # alors la compilation plutôt que de brider la physique.
        # (Un mode compile_column, qui compilait TOUT le pas, a été retiré le
        # 2026-08-19 : sa compilation échouait et retombait en eager en silence,
        # pour un résultat 1,5x PLUS LENT que l'eager franc — il forçait le sol
        # static, donc les 64 sous-pas s'exécutaient tous sans sortie anticipée.)
        if soil_n_substep > 64 and compile_soil:
            print(f"[colonne] compilation DÉSACTIVÉE : {soil_n_substep} sous-pas "
                  f"dérouleraient un graphe trop profond (limite ~64)")
            compile_soil = False
        soil_static = bool(compile_soil)
        # Plafond de sous-pas de Courant, réglable par MEANDRE_NSUBSTEP. Le C++ boucle
        # JUSQU'À épuiser le pas de temps ; le plafond est une concession au GPU. Plus le
        # sol est PERMÉABLE, plus la condition de Courant exige de sous-pas : sur GASP
        # (ks 4.6× celui d'OUTV) le plafond mord bien plus, l'eau du temps non traité part
        # au ruissellement par la fermeture de masse, et le sol s'assèche (theta1/theta2
        # à 0.63/0.55 d'Hydrotel contre 0.96/0.95 sur OUTV).
        self.soil = BV3C2Clone(n_substep=soil_n_substep, static=soil_static,
                               frozen_gate_continuous=frozen_gate_continuous,
                               horton_precomputed=horton_precomputed)
        if compile_soil:
            self.soil = torch.compile(self.soil, dynamic=False)
        # Ancrage OPTIONNEL sur la calibration Hydrotel (reproduce). None = init
        # NeRF/littérature (objectif ultime : découplé). Posé via set_calibrated_soil.
        self._calib_soil = None
        self._static = None      # posé par set_static()
        self.z1 = 0.15           # épaisseur couche 1 (config ; Z2/Z3 du NeRF)

        # ── Paramètres globaux apprenables (absents du NeRF) ──
        import math as _m
        self._b_bounds = (1.4, 6.0); self._psis_bounds = (0.01, 1.0); self._krec_bounds = (1e-7, 1e-4)
        def _inv(v, lo, hi):
            f = min(max((v - lo) / (hi - lo), 1e-4), 1 - 1e-4)
            return torch.tensor(_m.log(f / (1 - f)))
        tx = SOIL_TEXTURES["sandy_loam"]   # init Campbell (sera régionalisé plus tard)
        for i in (1, 2, 3):
            setattr(self, f"b{i}_raw", nn.Parameter(_inv(1.0 / tx["lam"], *self._b_bounds)))
            setattr(self, f"psis{i}_raw", nn.Parameter(_inv(tx["psis"], *self._psis_bounds)))
        self.log_etr_alpha = nn.Parameter(torch.tensor(_m.log(4.5)))      # assèchement ETR
        # fonte degré-jour par classe (softplus pour positivité), init Hydrotel 12/14/16
        self.sp_fonte_conif = nn.Parameter(torch.tensor(_m.log(_m.exp(12.0) - 1)))
        self.sp_fonte_feu = nn.Parameter(torch.tensor(_m.log(_m.exp(14.0) - 1)))
        self.sp_fonte_dec = nn.Parameter(torch.tensor(_m.log(_m.exp(16.0) - 1)))
        # ETI (mode "eti") : facteurs de fonte température (tf, m/°C/j) et radiation
        # (srf, m/j par W/m²), softplus pour positivité. Init Pellicciotti 2005 (neige,
        # journalier) : TF≈1.2 mm/°C/j, SRF≈0.0094 mm/j par W/m². (Corrigé 2026-07-13 :
        # l'ancienne init srf 0.2 mm/j/(W/m²) était ~20× trop forte → fonte radiative
        # ~30 mm/j au départ, cause de l'échec du run ETI cold-start du 2026-07-08.)
        self.sp_tf = nn.Parameter(torch.tensor(_m.log(_m.exp(0.0012) - 1)))
        self.sp_srf = nn.Parameter(torch.tensor(_m.log(_m.exp(9.4e-6) - 1)))
        # Hydrogramme unitaire de VERSANT (cascade de Nash 2 réservoirs, fidèle
        # Hydrotel — porté de column.py). Lisse le ruissellement AVANT le canal,
        # par étalement des temps de parcours (préserve les pics, contrairement à
        # l'atténuation Muskingum). DEUX échelles : surface POINTUE (k court),
        # interflow LARGE (k long). À coupler avec pure_advection (canal cinématique).
        if self.use_hillslope_uh:
            self.log_uh_k_surf = nn.Parameter(torch.tensor(_m.log(0.3)))    # ~0.3 j
            self.log_uh_k_inter = nn.Parameter(torch.tensor(_m.log(2.5)))   # ~2.5 j

    def _sig(self, raw, bounds):
        return bounds[0] + (bounds[1] - bounds[0]) * torch.sigmoid(raw)

    @staticmethod
    def _spline(b, psis):
        A = (1.0 + 2.0 * b) / (2.0 + 2.0 * b)
        psi_i = psis * A.pow(-b); dpsi_i = -psis * b * A.pow(-b - 1.0); r = psi_i / dpsi_i
        nn_ = (A * A - A - 2.0 * r * A + r) / (A - 1.0 - r)
        mm_ = -dpsi_i / (2.0 * A - nn_ - 1.0)
        return A, mm_, nn_

    # ── Paramètres statiques par nœud ───────────────────────────────────
    def set_static(self, p_snow: dict, p_soil: dict, p_etr: dict,
                   wetland: dict | None = None, n_depth: int = 31,
                   gel: dict | None = None) -> None:
        """Pose les paramètres statiques par nœud (une fois par simulate).
        p_snow : params DegreJourModifie (lat, ce1, ce0, pct_*, coeff_fonte_*, ...).
        p_soil : params BV3C2 (make_params : Campbell + fsa/fse/fsi + krec/cin/slope + z).
        p_etr  : params ETR (thetacc, thetapf, alpha, des, coef_assech, z11/z22/z33,
                 classes : liste de (pct, jours_bp, leaf_bp, root_bp)).
        wetland: params milieu humide par nœud (A,B,wetnvol,wetmxvol,wet_k,c_ev,
                 c_prod,hru_ha,wet_fr) ou None si aucun.
        n_depth: nombre de nœuds du profil de gel."""
        # gel : proprietes thermiques par noeud (kt_sol, c_sol, fs_neige) quand le
        # champ les produit. Absentes d'un ancien point de reprise, Rankinen retombe
        # sur ses scalaires C++ et le clone reste fidele.
        self._static = dict(snow=p_snow, soil=p_soil, etr=p_etr, wetland=wetland,
                            n_depth=n_depth, gel=gel or {})
        # Les breakpoints de phénologie sont convertis en tenseurs ICI, une fois par
        # simulate, et NON dans forward. La conversion (torch.as_tensor sur une liste
        # de tenseurs 0-d) est de la préparation de données : dans le pas, elle rendait
        # la colonne incompilable (dynamo échoue à tracer as_tensor sur des faux
        # tenseurs, mesuré le 2026-08-19) alors que la colonne est ~80 % du temps.
        _ref = p_soil.get("ks1")
        if _ref is None or (torch.is_tensor(_ref) and _ref.dim() == 0):
            # ignorer les scalaires 0-d (ex. un krec pose en tenseur scalaire par les
            # bancs) : la cle de cache a besoin de n_nodes, donc d'un tenseur 1-d.
            _ref = next((v for v in p_soil.values()
                         if torch.is_tensor(v) and v.dim() >= 1), None)
        self._pheno_cache = None
        self._pheno_cache_key = None
        if _ref is not None and p_etr.get("classes"):
            self._pheno_tensors(p_etr["classes"], _ref)

    def set_calibrated_soil(self, p_soil: dict):
        """Ancre le sol sur la calibration Hydrotel (params par nœud). Quand posé,
        params_from_nerf l'utilise À LA PLACE du sol NeRF (reproduce). Optionnel.
        Mémorise aussi les z médians pour rendre ETR/gel cohérents avec ces z."""
        self._calib_soil = p_soil
        # z absents = ancrage partiel (texture seule) : les épaisseurs restent au NeRF,
        # donc pas de mémorisation qui les figerait pour l'ETR et le gel.
        self._calib_z = (float(p_soil["z1"].median()), float(p_soil["z2"].median()),
                         float(p_soil["z3"].median())) if "z1" in p_soil else None

    # ── Seam NeRF/territorial → params (Phase A) ────────────────────────
    def params_from_nerf(self, sp, territorial, node_coords):
        """Assemble les params statiques par nœud depuis le NeRF (SpatialParams)
        et le territorial. Sol : thetas/ks/fc/wp/Z du NeRF, Campbell b/psis/krec
        globaux apprenables. Split fsa/fse/fsi FIDÈLE depuis l'occupation brute.
        Classes neige/ETR depuis l'occupation disponible (forêt agrégée si le
        split conif/feuillus brut manque — voir _raw_keep / rebuild).
        Pose le résultat via set_static() et retourne (p_snow, p_soil, p_etr)."""
        like = sp.porosity_1
        # OCCUPATION DU SOL : les fractions posées par set_land_cover() (PHYSITEL brut)
        # priment sur le territorial, dont les colonnes `f_*` de la base du Québec sont
        # CENTRÉES-RÉDUITES et dont les `f_*_raw` n'existent pas — voir
        # meandre.data.hydrotel_calib.load_occupation_sol.
        _lc = getattr(self, "_land_cover", None)
        _gp0 = territorial.get_physical
        gp = (lambda k: (_lc[k] if (_lc is not None and k in _lc) else _gp0(k)))
        z = lambda k, d: (gp(k) if gp(k) is not None else torch.full_like(like, d))

        # occupation brute
        f_water = z("f_water_raw", 0.0); f_lake = z("lake_fraction_raw", 0.0)
        f_urban = z("f_urban_raw", 0.0); f_forest = z("f_forest_raw", 0.0)
        f_wet = z("f_wetland_raw", 0.0)
        fse = torch.clamp(f_water + f_lake, 0.0, 1.0)
        fsi = torch.clamp(f_urban, 0.0, 1.0)
        fsa = torch.clamp(1.0 - fse - fsi, 0.0, 1.0)
        # GARDE-FOU D'ENTRÉES (dette #3 du registre). `get_physical` renvoie None quand
        # la colonne demandée n'existe pas, et le code prend alors un DÉFAUT sans le
        # moindre message : c'est ainsi que méandre a simulé le Québec avec 0 % de forêt
        # et 0 % d'eau libre pendant des mois. On imprime UNE FOIS ce que la physique
        # reçoit réellement, et on avertit si l'occupation est manifestement absente.
        if not getattr(self, "_entrees_verifiees", False):
            self._entrees_verifiees = True
            _ff, _fw = float(f_forest.mean()), float(f_water.mean())
            _fu, _fwe = float(f_urban.mean()), float(f_wet.mean())
            print(f"[colonne] occupation reçue : forêt {_ff:.3f} | eau {_fw:.3f} | "
                  f"imperméable {_fu:.3f} | humide {_fwe:.3f} | fsa {float(fsa.mean()):.3f}")
            if _ff + _fw + _fu + _fwe < 1e-6:
                print("[colonne] AVERTISSEMENT : occupation du sol TOUTE NULLE. Le "
                      "territoire sera traité comme du sol nu découvert (classe de neige "
                      "la plus fondante, aucun ruissellement sur l'eau libre). Vérifier "
                      "que les colonnes `f_*_raw` existent, ou poser set_land_cover().")
        # pente = géométrie universelle. Priorité : slope_fraction (présent dans le
        # cache PHYSITEL, déjà en fraction), sinon mean_slope_pct_raw/100, sinon défaut.
        slope_frac = gp("slope_fraction")
        if slope_frac is not None:
            slope = torch.clamp(slope_frac.to(like.dtype), 1e-3, 0.5)
        else:
            slope = torch.clamp(z("mean_slope_pct_raw", 4.0) / 100.0, 1e-3, 0.5)

        # orientation depuis l'aspect (sin/cos dans .data) → code 0-7
        try:
            si = territorial.data[:, territorial.columns.index("sin_aspect")]
            co = territorial.data[:, territorial.columns.index("cos_aspect")]
            asp = (torch.rad2deg(torch.atan2(si, co)) % 360.0)
            orient = torch.round(asp / 45.0) % 8
        except (ValueError, AttributeError):
            orient = torch.full_like(like, 7.0)
        lat = node_coords[:, 1].to(like.dtype)
        ce1, ce0 = init_ce(lat, slope, orient)

        # classes neige : forêt → feuillus (split conif brut indispo sur OD), reste découvert
        f_conif_raw = gp("f_forest_conifer_raw")
        if f_conif_raw is not None:        # disponible après rebuild → split fidèle
            pct_conif = f_conif_raw
            _mix = gp("f_forest_mixed_raw")
            pct_feu = gp("f_forest_deciduous_raw") + (_mix if _mix is not None else 0.0)
        else:                               # fallback OD : toute la forêt en feuillus
            pct_conif = torch.zeros_like(like); pct_feu = f_forest
        sp_ = torch.nn.functional.softplus
        # échelle de fonte par nœud (NeRF C_f / 4.5), sinon 1.0 partout
        if self.spatial_melt and hasattr(sp, "C_f"):
            mscale = torch.clamp(sp.C_f / 4.5, 0.15, 1.8)
        else:
            mscale = torch.ones_like(like)
        if getattr(self, "_melt_anchored", False):
            # ancrage RÉGIONAL (degre_jour_modifie.csv) : taux et seuils calés par
            # nœud ; spatial_melt (mscale) module multiplicativement autour.
            cf_c = self.melt_taux_c / 1000.0 * mscale
            cf_f = self.melt_taux_f / 1000.0 * mscale
            cf_d = self.melt_taux_d / 1000.0 * mscale
            se_c, se_f, se_d = self.melt_seuil_c, self.melt_seuil_f, self.melt_seuil_d
            tgeo, dmax, tass = self.melt_taux_geo, self.melt_dens_max, self.melt_tasse
            # SEUIL DE FONTE APPRIS PAR CLASSE (R56, opt-in). Les TAUX restent ancrés ;
            # seul le verrou -- la constante qui décide QUAND la fonte est permise --
            # redevient un champ. C'est la loi des ancrages appliquée à la lettre :
            # on garde du calage ce qui est une propriété de la surface, on rend au
            # NeRF ce qui était une compensation calée contre l'hydrogramme. La
            # structure (offsets positifs empilés) garantit conifère >= feuillu >=
            # découvert, donc les trois seuils ne peuvent pas se compenser entre eux.
            if self.canopy_melt_lag and hasattr(sp, "dT_canopee_feu"):
                se_d = sp.T_melt
                se_f = se_d + sp.dT_canopee_feu
                se_c = se_f + sp.dT_canopee_conif
        else:
            cf_c = sp_(self.sp_fonte_conif) / 1000.0 * mscale
            cf_f = sp_(self.sp_fonte_feu) / 1000.0 * mscale
            cf_d = sp_(self.sp_fonte_dec) / 1000.0 * mscale
            # SEUIL de fonte = champ T_melt du NeRF (par nœud, appris des attributs).
            # Était codé en dur à 0°C et T_melt était MORT (audit 2026-07-25) : LE
            # levier de timing du freshet (les seuils calés valent +0.15 KGE sur GASP).
            # Init/prior T_melt = -0.5°C (littérature), supervisable par w_snow MOD10.
            if self.spatial_melt and hasattr(sp, "T_melt"):
                se_c = se_f = se_d = sp.T_melt
            else:
                se_c = se_f = se_d = torch.zeros_like(like)
            tgeo = torch.full_like(like, 0.5); dmax = torch.full_like(like, 466.0)
            tass = torch.full_like(like, 0.1)
        p_snow = dict(lat=lat, ce1=ce1, ce0=ce0,
                      pct_conifers=pct_conif, pct_feuillus=pct_feu,
                      pct_autres=torch.clamp(1.0 - pct_conif - pct_feu, 0.0, 1.0),
                      coeff_fonte_conifers=cf_c,
                      coeff_fonte_feuillus=cf_f,
                      coeff_fonte_decouver=cf_d,
                      seuil_fonte_conifers=se_c, seuil_fonte_feuillus=se_f,
                      seuil_fonte_decouver=se_d,
                      taux_fonte_geo=tgeo, densite_max=dmax,
                      constante_tassement=tass,
                      melt_mode=self.melt_mode,
                      tf=sp_(self.sp_tf) * torch.ones_like(like),
                      srf=sp_(self.sp_srf) * torch.ones_like(like))
        # Modulation saisonniere du facteur de fonte (R32, opt-in) : posee par le
        # pilote via `melt_seasonal_amp` (float). None = clone fidele a l'identique.
        _msa = getattr(self, "melt_seasonal_amp", None)
        if _msa is not None:
            p_snow["melt_seasonal_amp"] = float(_msa)

        # sol BV3C2 : NeRF (thetas/ks) + Campbell global
        b1 = self._sig(self.b1_raw, self._b_bounds); b2 = self._sig(self.b2_raw, self._b_bounds); b3 = self._sig(self.b3_raw, self._b_bounds)
        ps1 = self._sig(self.psis1_raw, self._psis_bounds); ps2 = self._sig(self.psis2_raw, self._psis_bounds); ps3 = self._sig(self.psis3_raw, self._psis_bounds)
        o1, m1, n1 = self._spline(b1, ps1); o2, m2, n2 = self._spline(b2, ps2); o3, m3, n3 = self._spline(b3, ps3)
        ob = lambda v: v * torch.ones_like(like)
        p_soil = dict(z1=torch.full_like(like, self.z1), z2=sp.Z2, z3=sp.Z3,
                      thetas1=sp.porosity_1, thetas2=sp.porosity_2, thetas3=sp.porosity_3,
                      ks1=sp.K_sat_1 / 24.0, ks2=sp.K_sat_2 / 24.0, ks3=sp.K_sat_3 / 24.0,
                      b1=ob(b1), b2=ob(b2), b3=ob(b3), psis1=ob(ps1), psis2=ob(ps2), psis3=ob(ps3),
                      omegpi1=ob(o1), omegpi2=ob(o2), omegpi3=ob(o3), mm1=ob(m1), mm2=ob(m2), mm3=ob(m3),
                      nn1=ob(n1), nn2=ob(n2), nn3=ob(n3),
                      # RECHARGE : CHAMP par noeud, sortie du NeRF depuis le
                      # 2026-08-20. C'etait un scalaire global -- une seule valeur pour
                      # toute une region -- ce qui interdisait de suivre la geologie, de
                      # repondre a l'urbanisation d'un territoire agricole, ou d'etre
                      # confronte a une carte regionale allant de 0 a 400 mm/an. Le
                      # scalaire krec_raw est RETIRE : le laisser en repli en aurait
                      # fait une quatorzieme sortie morte (dette #5 du registre).
                      krec=sp.krec,
                      slope=slope, cin=torch.full_like(like, 0.03),
                      fsa=fsa, fse=fse, fsi=fsi, coef_recharge=torch.zeros_like(like))
        # Drainage non lineaire de L3 (opt-in, R37) : posee par le pilote via
        # `l3_drain_exp` (float). None = drainage lineaire fidele.
        # ── DRAINAGE SOUTERRAIN AGRICOLE (opt-in, O12) ──────────────────────
        # `drainage_agricole` = dict(espacement_m, profondeur_m, part_cultive) ou None.
        # La fraction drainee est DERIVEE de l'occupation : part_cultive x f_agriculture,
        # ce qui evite d'inventer un champ la ou l'attribut existe deja. Le NeRF peut
        # ensuite moduler l'espacement s'il devient une sortie ; pour le premier test il
        # reste un scalaire, parce qu'on veut mesurer un PROCESSUS et non un parametre
        # de plus.
        _drn = getattr(self, "drainage_agricole", None)
        if _drn is not None:
            # La fraction agricole n'existe qu'en version NORMALISEE dans les attributs
            # du champ (z-score) : inutilisable comme fraction. Elle arrive donc par
            # l'occupation du sol, ou le chargeur provincial la pose en brut. Absente,
            # on draine tout le sol, ce qui n'a de sens que pour un test unitaire.
            _lcd = getattr(self, "_land_cover", None) or {}
            _fag = _lcd.get("pct_agricole")
            if _fag is None:
                _fag = torch.ones_like(like)
            p_soil["drain_spacing"] = torch.full_like(like, float(_drn["espacement_m"]))
            p_soil["drain_depth"] = torch.full_like(like, float(_drn["profondeur_m"]))
            p_soil["drain_frac"] = torch.clamp(
                float(_drn.get("part_cultive", 0.6)) * torch.as_tensor(_fag).to(like),
                0.0, 1.0)
        _l3n = getattr(self, "l3_drain_exp", None)
        if _l3n is not None:
            p_soil["l3_drain_exp"] = float(_l3n)

        # Ancrage Hydrotel (reproduce) : remplace le sol NeRF par la calibration
        # par nœud si fournie. Optionnel — retiré pour découpler.
        if self._calib_soil is not None:
            # FUSION et non remplacement : une clé absente du calage garde la valeur du
            # NeRF. Permet d'hériter de la géométrie et de l'hydraulique calibrées par
            # Hydrotel tout en laissant libre la partition verticale (krec), qu'Hydrotel
            # étrangle faute d'aquifère et dont méandre, lui, se sert.
            p_soil = {**p_soil, **{k: v.to(like.device).to(like.dtype)
                                   for k, v in self._calib_soil.items()}}

        # ETR : thetacc/thetapf du NeRF (couche 1), alpha global ; classes dispo
        alpha = torch.exp(self.log_etr_alpha)
        # PHÉNOLOGIE : profils du PROJET Hydrotel (physio/ind_fol.def et pro_rac.def)
        # s'ils ont été posés par set_phenology(), sinon les tables codées en dur.
        # Écarts mesurés sur OUTV : racines des conifères 1.531 m contre 1.0 chez nous,
        # milieux humides 1.531 contre 0.75, agriculture 0.108 contre 0.8 ; feuillus à
        # indice foliaire nul en hiver contre un plancher à 3.
        _ph = getattr(self, "_pheno", None)
        def _prof(cl):
            if _ph is not None and cl in _ph:
                return _ph[cl]
            return _JBP, _LEAF[cl], _ROOT[cl]
        et_classes = []
        if pct_feu.sum() > 0:
            et_classes.append((pct_feu, *_prof("feuillus")))
        if pct_conif.sum() > 0:
            et_classes.append((pct_conif, *_prof("conifers")))
        if f_wet.sum() > 0:
            et_classes.append((f_wet, *_prof("humides")))
        # DÉFICIT D'ETR D'ÉTÉ (corrigé le 2026-08-10) : seules forêt et milieu humide
        # recevaient une classe de végétation, soit 79.6 % du territoire sur OUTV.
        # L'agriculture (12 %) et le sol nu ne transpiraient PAS DU TOUT, alors que les
        # profils existent dans _LEAF/_ROOT. Il en résultait ~12 % de production
        # excédentaire, concentrée en juillet-octobre (rapports 1.48 à 1.59 contre
        # Hydrotel). On ajoute l'agriculture puis on verse le RÉSIDU de la fraction
        # perméable en classe ouverte, pour que l'ETR couvre bien tout fsa.
        pct_agri = z("f_agriculture_raw", 0.0)
        if pct_agri.sum() > 0:
            et_classes.append((pct_agri, *_prof("agri")))
        if et_classes:
            _couvert = pct_feu + pct_conif + f_wet + pct_agri
            _reste = torch.clamp(fsa - _couvert, min=0.0)
            if _reste.sum() > 0:
                et_classes.append((_reste, *_prof("ouverts")))
        # DÉGRADATION GRACIEUSE : sans descriptif d'occupation (ex réseau PHYSITEL,
        # qui ne porte pas les fractions par classe), l'ET ne doit PAS tomber à 0.
        # Classe végétation par défaut sur la fraction perméable (LAI/racines
        # génériques boréal QC). La variation spatiale de l'ET vient alors du NeRF
        # (thetacc/thetapf/ks → stress + eau dispo) + alpha apprenable. Occupation
        # = optionnelle, pas un prérequis (objectif découplage).
        if not et_classes:
            et_classes.append((fsa, _JBP, _LEAF["default"], _ROOT["default"]))
        # z des couches : calibrés Hydrotel si ancré (cohérence ETR/gel/sol), sinon NeRF.
        #
        # GRADIENT (2026-09-03). `float(sp.Z2.mean())` faisait DEUX choses à la fois :
        # il fournissait un scalaire au maillage de gel, qui en exige un pour compter ses
        # intervalles, et il alimentait la voie racinaire de l'évapotranspiration. Sur
        # cette seconde voie la conversion en flottant coupe le graphe : Z2 et Z3 n'y
        # recevaient aucun gradient, et toute leur variation spatiale était écrasée par
        # une moyenne. Asymétrie silencieuse, le sol les lisant par ailleurs comme des
        # tenseurs. `calcule_etr` accepte déjà l'un ou l'autre (il convertit les scalaires
        # en tenseurs), donc les deux usages se séparent sans risque.
        # MEANDRE_Z_TENSEUR=0 restitue l'ancien comportement, pour comparaison.
        _z_tenseur = os.environ.get("MEANDRE_Z_TENSEUR", "1") == "1"
        # .detach() explicite : ces deux scalaires ne servent QU'A dimensionner le
        # maillage de gel. Sans lui, torch emet un avertissement de conversion qui
        # finirait par masquer une vraie fuite de gradient.
        z22_s = float(sp.Z2.detach().mean())
        z33_s = float(sp.Z3.detach().mean())
        z11 = self.z1
        z22, z33 = (sp.Z2, sp.Z3) if _z_tenseur else (z22_s, z33_s)
        if self._calib_soil is not None and self._calib_z is not None:
            z11, z22, z33 = self._calib_z
            z22_s = float(z22.detach().mean()) if torch.is_tensor(z22) else float(z22)
            z33_s = float(z33.detach().mean()) if torch.is_tensor(z33) else float(z33)
        # K_c (coefficient cultural) par nœud, prédit par le NeRF (borné [0.3,1.5],
        # prior vers 0.85). Multiplie l'ETP → corrige la sur-évaporation McGuinness
        # et laisse le NeRF caler le volume (β) par nœud. Levier de découplage.
        kc = sp.K_c if hasattr(sp, "K_c") else torch.ones_like(like)
        p_etr = dict(thetacc=sp.theta_fc_1, thetapf=sp.theta_wp_1, alpha=alpha * torch.ones_like(like),
                     des=torch.full_like(like, 0.6), coef_assech=torch.full_like(like, 1.0),
                     z11=z11, z22=z22, z33=z33, classes=et_classes, K_c=kc)

        # milieu humide isolé : actif SI le territorial porte la géométrie par nœud
        # (wet_a_raw). Sinon None (colonne sol seul, ex SLSO). Masqué + sûr gradient.
        wetland = self._wetland_from_territorial(territorial, like)

        # Le maillage de gel compte des intervalles : il lui faut un SCALAIRE.
        n_depth = n_intervalles(float(z11) + z22_s + z33_s, self.frost.dz)
        self.set_static(p_snow, p_soil, p_etr, wetland=wetland, n_depth=n_depth,
                        gel={k: getattr(sp, k, None)
                             for k in ("diff_gel", "fs_neige")})
        if self.use_aquifer:
            self._static["k_gw"] = sp.k_gw   # récession aquifère par nœud (1/j)
        return p_snow, p_soil, p_etr

    def _wetland_from_territorial(self, territorial, like):
        """Construit le dict milieu humide isolé par nœud depuis territorial.physical
        (colonnes *_raw agrégées UHRH→troncon par le loader). Retourne None si pas de
        géométrie (wet_a_raw absent). Les nœuds sans MH sont masqués (wmask) et reçoivent
        une géométrie factice positive pour éviter log10(0)=NaN dans le gradient."""
        from hydrotel_clone.milieu_humide import wetland_geom_vec
        # même priorité que _static_params : les entrées posées par set_land_cover()
        # (chargées du projet Hydrotel) priment sur le territorial, dont AUCUN cache du
        # Québec ne porte wet_a_raw — d'où un module de milieu humide jamais instancié.
        _lc = getattr(self, "_land_cover", None)
        _gp0 = territorial.get_physical
        gp = (lambda k: (_lc[k] if (_lc is not None and k in _lc) else _gp0(k)))
        wet_a = gp("wet_a_raw")
        if wet_a is None:
            return None
        z = lambda k, d: (gp(k) if gp(k) is not None else torch.full_like(like, d))
        area = torch.clamp(z("area_km2_local", 1.0), min=1e-6)   # aire locale du troncon [km2]
        wetdmax = z("wetdmax_raw", 0.3); frac = z("frac_raw", 0.8); wetdnor = z("wetdnor_raw", 0.2)
        wet_dra_fr = z("wet_dra_fr_raw", 0.0)
        wet_k = z("ksat_bs_raw", 0.5); c_ev = z("c_ev_raw", 0.6); c_prod = z("c_prod_raw", 10.0)
        # Constante de vidange imposable (R39, voie rapide-lente) : c_prod est la
        # duree de restitution du stock de crue au-dessus du volume normal (defaut
        # SWAT 10 j). L'override permet de tester la retention de quelques semaines
        # sans toucher aux donnees PHYSITEL. None = fidele.
        if getattr(self, "c_prod_override", None) is not None:
            c_prod = torch.full_like(like, float(self.c_prod_override))
        wmask = wet_a > 0.0
        # géométrie factice POSITIVE sur les nœuds sans MH (sinon log10(0)=−inf→NaN
        # dans wetland_geom_vec ; ces nœuds sont masqués en aval de toute façon).
        wet_a_safe = torch.where(wmask, wet_a, torch.ones_like(wet_a))
        wetdmax_s = torch.where(wmask, wetdmax, torch.full_like(wetdmax, 0.3))
        frac_s = torch.where(wmask, frac, torch.full_like(frac, 0.8))
        wetdnor_s = torch.where(wmask, wetdnor, torch.full_like(wetdnor, 0.2))
        A, B, wetnvol, wetmxvol = wetland_geom_vec(wet_a_safe, wetdmax_s, frac_s, wetdnor_s)
        return dict(wet_fr_area=torch.clamp(wet_a / area, 0.0, 1.0), hru_ha=area * 100.0,
                    wet_dra_fr=torch.where(wmask, wet_dra_fr, torch.zeros_like(wet_dra_fr)),
                    A=A, B=B, wetnvol=wetnvol, wetmxvol=wetmxvol,
                    wet_k=wet_k, c_ev=c_ev, c_prod=c_prod, wmask=wmask)

    # ── État initial ────────────────────────────────────────────────────
    def init_state(self, n_nodes, theta_init, swe_init_mm=None, device="cpu",
                   dtype=torch.float64) -> HydrotelColumnState:
        sn = snow_init_state(n_nodes, device=device, dtype=dtype)
        z = lambda v: torch.full((n_nodes,), float(v), device=device, dtype=dtype)
        nd = self._static["n_depth"] if self._static else 31
        frost_profile = torch.full((n_nodes, nd), self.frost.temp_ini_base, device=device, dtype=dtype)
        _uh = (torch.zeros(n_nodes, device=device, dtype=dtype) if self.use_hillslope_uh else None)
        return HydrotelColumnState(
            theta1=z(theta_init[0]), theta2=z(theta_init[1]), theta3=z(theta_init[2]),
            snow=sn, frost_profile=frost_profile, wet_vol=torch.zeros(n_nodes, device=device, dtype=dtype),
            uh_s1=(_uh.clone() if _uh is not None else None),
            uh_s2=(_uh.clone() if _uh is not None else None),
            uh_s3=(_uh.clone() if _uh is not None else None),
            uh_s4=(_uh.clone() if _uh is not None else None))

    # ── Adaptateur interface VerticalColumn (pour model.py simulate) ────
    def setup_simulate(self, spatial_params, territorial, node_coords, init_state,
                       poursuivre: bool = False):
        """Assemble les params depuis le NeRF et prépare l'état interne riche.

        POURSUIVRE (défaut False, comportement historique). L'état interne de la colonne
        (manteau neigeux par classe, profil de gel multicouche, volume de milieu humide,
        cascade de versant) ne tient pas dans `HydroState` : il vit dans `self._aux`. Un
        appel à `simulate` le reconstruisait donc TOUJOURS à neuf, en ne recopiant que
        les teneurs en eau. Or l'entraînement appelle `simulate` une fois par bloc de 45
        jours : le manteau, le gel et le milieu humide repartaient de zéro six fois par
        an, et l'entraînement n'a jamais simulé d'hiver continu (mesure du 2026-09-03 :
        538,86 mm d'équivalent en eau effacés à une frontière de bloc, voir
        `tests/test_chunk_state_annihilation.py`). Les gradients du facteur de fonte et
        du seuil pluie-neige étaient appris sur des manteaux de deux semaines quand
        l'évaluation juge une trajectoire continue de trois ans.

        Avec `poursuivre=True`, l'état interne est CONSERVÉ et détaché (le détachement
        est ce que fait déjà la troncature du gradient entre blocs) ; seules les teneurs
        en eau sont resynchronisées depuis l'état entrant, qui peut porter une correction
        appliquée en dehors de la colonne. Les paramètres sont toujours relus du champ,
        qui a bougé entre deux blocs.
        """
        self.params_from_nerf(spatial_params, territorial, node_coords)
        n = init_state.theta1.shape[0]
        dev, dt = init_state.theta1.device, init_state.theta1.dtype
        ancien = getattr(self, "_aux", None)
        if (poursuivre and ancien is not None
                and getattr(ancien, "theta1", None) is not None
                and ancien.theta1.shape[0] == n):
            aux = ancien.detach()
            aux.theta1, aux.theta2, aux.theta3 = (init_state.theta1, init_state.theta2,
                                                  init_state.theta3)
            self._aux = aux
            return
        aux = self.init_state(n, theta_init=(0.0, 0.0, 0.0), device=dev, dtype=dt)
        aux.theta1, aux.theta2, aux.theta3 = init_state.theta1, init_state.theta2, init_state.theta3
        # volume initial du milieu humide depuis le territorial si dispo (sinon 0)
        wv0 = territorial.get_physical("wet_vol_init_raw")
        if wv0 is not None:
            aux.wet_vol = wv0.to(dev).to(dt)
        self._aux = aux

    def detach_aux(self):
        if getattr(self, "_aux", None) is not None:
            self._aux = self._aux.detach()

    def column_step(self, enriched, state, doy=None, return_diagnostics=False,
                    gw_withdrawal_mm=None, **_):
        """Un pas, interface ColumnOutput. enriched[:, :6] = P,Tmin,Tmax,Rn,u2,ea.
        theta est re-synchronisé depuis `state` (pour intégrer une éventuelle
        correction résiduelle), le reste de l'état riche est interne (self._aux).
        gw_withdrawal_mm : prélèvement/rejet souterrain (mm/j, +ajout/−retrait)."""
        from meandre.utils.state import ColumnOutput
        a = self._aux
        a.theta1, a.theta2, a.theta3 = state.theta1, state.theta2, state.theta3
        P, tmin, tmax = enriched[:, 0], enriched[:, 1], enriched[:, 2]
        Rn, u2, ea = enriched[:, 3], enriched[:, 4], enriched[:, 5]
        # Fonte ETI : courte longueur d'onde incidente brute = canal FB (index 6).
        sw_in = enriched[:, self.sw_channel] if self.sw_channel is not None else None
        # Hortonien sous-journalier : durée effective d'orage DT_eff = canal (index storm_channel).
        storm_hours = enriched[:, self.storm_channel] if self.storm_channel is not None else None
        # ET APPRIS (design_et_appris.md étape 2) : demande évaporative précalculée par le
        # module supervisé MOD16, injectée comme canal de forçage. Remplace formule ETP × K_c ;
        # l'extraction par couche et les scaling factors restent intacts (conservation).
        etp_ext = enriched[:, self.etp_channel] if getattr(self, "etp_channel", None) is not None else None
        prod, a, diag = self.forward(P, tmin, tmax, Rn, u2, ea,
                                     doy if doy is not None else 1, a, sw_in=sw_in, storm_hours=storm_hours,
                                     etp_ext=etp_ext)
        self._aux = a
        # Prélèvements/rejets SOUTERRAINS. La colonne Hydrotel fidèle n'a pas de
        # réservoir d'aquifère restituant (cf. C++ : la recharge fuit, le baseflow
        # pb est généré instantanément depuis le drainage L3). Un prélèvement
        # souterrain intercepte donc l'eau qui serait devenue baseflow CE JOUR :
        # on l'applique à pb (et donc à prod = ps_surf+ph+pb), borné >= 0. Signe :
        # +ajout (recharge artificielle/rejet), −retrait (pompage), cohérent avec
        # WithdrawalData/AquiferModule. forward() (validé décimale) reste intouché.
        pb = diag["prod_base"]
        # La RECHARGE est le drainage profond de la couche 3 AVANT l'aquifère : c'est
        # un livrable du projet (la réalité québécoise se compte en dizaines à centaines
        # de mm/an), pas un sous-produit. Elle était rendue à ZÉRO EN DUR plus bas, si
        # bien qu'un diagnostic pouvait afficher 0 mm/an pendant que la nappe fournissait
        # 27 % du débit (mesuré le 2026-08-19).
        recharge_mm = pb
        if self.use_aquifer:
            # AQUIFÈRE RESTITUANT : le drainage L3 (pb) RECHARGE un réservoir linéaire
            # au lieu de sortir instantanément. Soutien d'étiage + prélèvement souterrain
            # agissent sur la VRAIE réserve (cf. AquiferModule). k_gw par nœud, GRACE le
            # contraint. prod = ps_surf+ph+pb -> on remplace pb par le baseflow retardé.
            kgw = self._static.get("k_gw")
            # NAPPE NON LINEAIRE (opt-in, R38/INT3, 2026-08-22). Le reservoir lineaire
            # relache a taux fixe : avec une recharge devenue saisonniere (L3 qui
            # respire), il etale la crue au lieu de la restituer -- INT3 : avril 0.59,
            # mai 1.27, base plate a 22-29 mm/mois. Q = q_ref*(S/100)^b relache vite a
            # stock plein (printemps) et lentement a stock bas (etiage) : les deux
            # constantes de temps mesurees (37 j et 111 j) avec un seul jeu de params.
            if getattr(self, "gw_power_law", None) is not None:
                _qr, _b = self.gw_power_law
                Q_bf, S_gw_new = self._pl_aquifer(
                    pb, state.S_gw,
                    q_ref=torch.full_like(pb, float(_qr)),
                    b=torch.full_like(pb, float(_b)),
                    gw_withdrawal=gw_withdrawal_mm)
            else:
                Q_bf, S_gw_new = self.aquifer(pb, state.S_gw, kgw, gw_withdrawal=gw_withdrawal_mm)
            prod = prod - pb + Q_bf
            diag["prod_base"] = Q_bf
            diag["lateral_mm"] = prod
        else:
            S_gw_new = state.S_gw
            if gw_withdrawal_mm is not None:
                pb_new = torch.clamp(pb + gw_withdrawal_mm, min=0.0)
                prod = prod + (pb_new - pb)
                diag["prod_base"] = pb_new
                diag["lateral_mm"] = prod
        new_state = HydroState(
            theta1=a.theta1, theta2=a.theta2, theta3=a.theta3,
            swe=diag["couvert_nival_mm"], t_soil=a.frost_profile[:, 0],
            canopy_storage=state.canopy_storage, wetland_storage=state.wetland_storage,
            S_gw=S_gw_new, T_water=state.T_water,
            cold_content=state.cold_content, gdd_cum=state.gdd_cum)
        return ColumnOutput(
            lateral_inflow=prod, state=new_state, snowmelt=diag["apport"],
            recharge=recharge_mm, Q_baseflow=diag["prod_base"],
            diag=(diag if return_diagnostics else None))

    # ── Split de phase pluie/neige FIDÈLE (THIESSEN::PassagePluieNeige, thiessen1.cpp:259-279) ──
    def _split_precip(self, P, tmin, tmax, ea=None):
        """Partition graduée pluie/neige au pas journalier. taux = fraction PLUIE :
        0 si tmax<seuil (tout neige), 1 si tmin>=seuil (tout pluie), sinon
        (tmax-seuil)/(tmax-tmin). Retourne (pluie, neige) en SWE (snow.py convertit
        en hauteur en interne). Seuil = t_neige_seuil (DELISLE 0°C).

        MODE BULBE HUMIDE (opt-in, `split_mode = "wet_bulb"`, 2026-08-22). Remarque
        d'Essi sur R35 : un seuil AIR calibre par region (+0.3 sur OUTV) est un
        parametre regional de plus, alors qu'on veut se defaire de la notion de
        region. La variable physique du partage est la temperature du BULBE HUMIDE :
        un flocon dans l'air sec refroidit par evaporation et survit a +2 ou +3
        degres, dans l'air sature il fond des 0. Jennings et al. 2018 (Nat. Comm.)
        mesurent des seuils AIR de 0.6 a 3.8 degres a travers l'hemisphere, dont la
        variance est essentiellement l'humidite : un seuil unique en bulbe humide
        absorbe la geographie SANS parametre regional. Verifie sur nos 6 regions :
        le seuil Twb equivalent au +0.3 air d'OUTV tient dans [-1.0, -0.7] partout
        (air : il varierait avec l'humidite). Twb par Stull 2011 (valide -20..50
        degres, HR > 5 %), HR reconstruite de e_a deja present dans le forcage.
        Les bornes tmin/tmax gardent leur role de partage INTRA-JOUR ; c'est le
        SEUIL qui se deplace de l'air vers le bulbe humide : s_eff = seuil + (T - Twb),
        ce qui revient a comparer Twb au seuil en gardant la graduation journaliere."""
        s = self.t_neige_seuil
        if getattr(self, "split_mode", "air") == "wet_bulb" and ea is not None:
            T = (tmin + tmax) / 2.0
            es = 0.6108 * torch.exp(17.27 * T / (T + 237.3))          # kPa, sur eau
            rh = torch.clamp(ea / es, 0.05, 1.0) * 100.0              # %
            twb = (T * torch.atan(0.151977 * torch.sqrt(rh + 8.313659))
                   + torch.atan(T + rh) - torch.atan(rh - 1.676331)
                   + 0.00391838 * rh ** 1.5 * torch.atan(0.023101 * rh) - 4.686035)
            s = s + (T - twb)     # comparer Twb au seuil == relever le seuil AIR de T-Twb
        taux = torch.clamp((tmax - s) / (tmax - tmin + 1e-6), 0.0, 1.0)   # fraction pluie
        taux = torch.where(tmax < s, torch.zeros_like(taux), taux)
        taux = torch.where(tmin >= s, torch.ones_like(taux), taux)
        return taux * P, (1.0 - taux) * P   # pluie (SWE), neige (SWE)

    # ── ETP au choix ────────────────────────────────────────────────────
    def set_linacre_params(self, lat, alti, t_froid, t_chaud, albedo, coeff):
        """Params Linacre par nœud (agrégés UHRH→troncon depuis linacre.csv de la
        plateforme régionale). coeff = COEFFICIENT MULTIPLICATIF OPTIMISATION =
        le calage régional d'ETP des plateformes LN24HA (~0.4-0.5)."""
        for nm, v in [("lin_lat", lat), ("lin_alti", alti), ("lin_tfroid", t_froid),
                      ("lin_tchaud", t_chaud), ("lin_albedo", albedo), ("lin_coeff", coeff)]:
            self.register_buffer(nm, torch.as_tensor(v, dtype=torch.get_default_dtype()), persistent=False)

    def set_mcguinness_coeff(self, coeff):
        """Coefficient multiplicatif d'optimisation de l'ETP McGuinness, par nœud
        (etp-mc-guiness.csv de la plateforme). Voir load_mcguinness_nodes."""
        if coeff is None:
            self.mcg_coeff = None
        else:
            self.register_buffer("mcg_coeff", torch.as_tensor(coeff, dtype=torch.get_default_dtype()),
                                 persistent=False)

    def set_phenology(self, ph: dict | None):
        """Profils phénologiques par classe, {classe: (jours, indice_foliaire,
        profondeur_racinaire)}, en général chargés du projet Hydrotel par
        load_phenologie(). Priment sur les tables codées en dur _LEAF/_ROOT."""
        self._pheno = ph

    def set_land_cover(self, lc: dict | None):
        """Fractions d'occupation du sol BRUTES par nœud (clés `f_*_raw`), en général
        chargées de PHYSITEL par load_occupation_sol(). Priment sur le territorial dans
        _static_params : classes de neige (conifères / feuillus / découvert), split
        fsa/fse/fsi, phénologie de l'ETR."""
        self._land_cover = lc

    def set_melt_params(self, mp: dict):
        """Params fonte RÉGIONAUX par nœud (degre_jour_modifie.csv du calage
        plateforme) : seuils par classe, taux par classe (mm/j/C), densité max,
        tassement, taux géothermique. Remplacent les init globales 12/14/16 et
        les seuils 0. Compatible spatial_melt (le NeRF module autour)."""
        for k, v in mp.items():
            self.register_buffer(f"melt_{k}", torch.as_tensor(v, dtype=torch.get_default_dtype()), persistent=False)
        self._melt_anchored = True

    def _etp(self, tmin_j, tmax_j, Rn, u2, ea, lat, doy, couv=None, albn=None):
        if self.et_mode == "linacre":
            # clone fidèle linacre.cpp (validé à la décimale sur MONT 4780 UHRH) ;
            # couv/albn = couvert nival + albédo du module neige interne.
            from hydrotel_clone.linacre import linacre_etp
            assert hasattr(self, "lin_coeff"), "et_mode=linacre : appeler set_linacre_params()"
            z = torch.zeros_like(tmin_j)
            return linacre_etp(tmin_j, tmax_j, self.lin_lat, self.lin_alti,
                               couv if couv is not None else z,
                               albn if albn is not None else z,
                               t_froid=self.lin_tfroid, t_chaud=self.lin_tchaud,
                               albedo=self.lin_albedo, coeff=self.lin_coeff)
        if self.et_mode == "mcguinness":
            # COEFFICIENT D'OPTIMISATION de la plateforme (etp-mc-guiness.csv) : 0.600
            # sur MG24HK, 0.850 sur MG24HS. Sans lui l'ETP est jusqu'à 67 % trop forte.
            _cmg = getattr(self, "mcg_coeff", None)
            _e = mcguinness_etp(tmin_j, tmax_j, lat, doy)
            return _e if _cmg is None else _e * _cmg
        if self.et_mode == "hydro_quebec":
            return hydro_quebec_etp(tmin_j, tmax_j)
        if self.et_mode == "oudin":
            # EXP-3 : Oudin et al. (2005), ETP température-radiation. Oudin a comparé
            # 27 formules d'ETP pour la modélisation pluie-débit et trouvé cette forme
            # simple optimale. Ne dépend que de T + lat + doy (compatible quebec.zarr,
            # pas besoin de Rn/vent). PE = (Re/λ)·(Ta+5)/100, gated Ta+5>0.
            from hydrotel_clone.mcguinness import rayonnement_extraterrestre, _LAMBDA
            import torch as _t
            Re = rayonnement_extraterrestre(doy, lat)          # MJ/m²/j
            Ta = 0.5 * (tmin_j + tmax_j)
            return _t.clamp((Re / _LAMBDA) * (Ta + 5.0) / 100.0, min=0.0)  # mm/j
        if self.et_mode == "penman":
            from meandre.vertical.evapotranspiration import ETModule
            return ETModule("penman").penman_monteith(tmin_j, tmax_j, Rn, u2, ea)
        raise ValueError(f"et_mode inconnu: {self.et_mode}")

    def _pheno_tensors(self, classes, ref):
        """Cache les breakpoints phénologie (jbp/leaf/root) en tenseurs au device/
        dtype de ref, construits une seule fois. Évite numpy + alloc par pas."""
        # n_nodes dans la clé : en entraînement CONJOINT multi-régions, la même
        # colonne sert plusieurs régions — sans ça, la cache resservait les pct
        # de la région précédente (mismatch de tailles).
        # ref 0-d tolere (bancs qui passent des scalaires) : n_nodes vaut alors 1.
        key = (ref.device, ref.dtype, int(ref.shape[0]) if ref.dim() else 1)
        if getattr(self, "_pheno_cache_key", None) != key:
            T = lambda v: torch.as_tensor(v, dtype=ref.dtype, device=ref.device)
            self._pheno_cache = [(pct, T(jbp), T(leaf_bp), T(root_bp))
                                 for (pct, jbp, leaf_bp, root_bp) in classes]
            self._pheno_cache_key = key
        return self._pheno_cache

    def forward(self, P, tmin, tmax, Rn, u2, ea, doy, state: HydrotelColumnState,
                tmin_j=None, tmax_j=None, sw_in=None, storm_hours=None, etp_ext=None) -> tuple[Tensor, HydrotelColumnState, dict]:
        """Un pas de temps. P/tmin/tmax/Rn/u2/ea : forçage (n_nodes,). doy : jour
        julien (scalaire ou n_nodes). Retourne (prod_totale_mm, new_state, diag)."""
        assert self._static is not None, "appeler set_static() avant forward()"
        ps, pso, pe = self._static["snow"], self._static["soil"], self._static["etr"]
        _pg = self._static.get("gel") or {}
        tmin_j = tmin if tmin_j is None else tmin_j
        tmax_j = tmax if tmax_j is None else tmax_j
        doy_t = (doy.to(P.dtype) if torch.is_tensor(doy)
                 else torch.tensor(float(doy), dtype=P.dtype, device=P.device))

        # 1. split pluie/neige → fonte neige → apport
        pluie, neige = self._split_precip(P, tmin, tmax, ea=ea)
        apport, snow_new = self.snow(tmin, tmax, pluie, neige, doy_t, state.snow, ps, sw_in=sw_in)

        # ── SUBLIMATION du manteau (opt-in, R32, 2026-08-22) ─────────────────
        # Kuzmin 1957, la parametrisation la plus simple de Raven (SUBLIM_KUZMIN) : elle
        # ne demande que u2 et e_a, deja dans le forcage. C'est une SORTIE D'EAU VERS
        # L'ATMOSPHERE : elle doit etre exposee au diagnostic (subl_mm), sinon l'audit
        # de fermeture (ETL_BILAN) lirait une fuite -- exactement le piege du milieu
        # humide (dette #12). La masse part de chaque classe au prorata du stock, et
        # hauteur/chaleur/eau retenue partent dans la meme proportion (la densite et la
        # temperature du manteau restant ne changent pas).
        subl_mm = None
        if getattr(self, "sublimation_mode", None) == "kuzmin":
            from hydrotel_clone.snow import sublimation_kuzmin, DegreJourModifie as _DJM
            t_air = (tmin + tmax) / 2.0
            pot_m = sublimation_kuzmin(u2, ea, t_air) / 1000.0     # m/j potentiel
            subl_tot = torch.zeros_like(pot_m)
            for c in _DJM.CLASSES:
                st, ha, ch, er = snow_new[c]
                pris = torch.minimum(pot_m, st)                     # borne par le stock
                frac = torch.where(st > 0, (st - pris) / st.clamp(min=1e-12),
                                   torch.ones_like(st))
                snow_new[c] = (st - pris, ha * frac, ch * frac, er * frac)
                pct_c = ps["pct_" + c] if c != "decouver" else ps["pct_autres"]
                subl_tot = subl_tot + pct_c * pris
            snow_new["couvert_nival_mm"] = sum(
                (ps[f"pct_{c}"] if c != "decouver" else ps["pct_autres"]) * snow_new[c][0]
                for c in _DJM.CLASSES) * 1000.0
            subl_mm = subl_tot * 1000.0

        # hauteur agrégée du couvert nival [m] pour le gel
        haut = sum(ps[f"pct_{c}" if c != "decouver" else "pct_autres"] * snow_new[c][1]
                   for c in DegreJourModifie.CLASSES)

        # 2. gel RANKINEN → profondeur de gel [cm]
        if self.use_frost:
            # PROPRIETES THERMIQUES DU CHAMP (2026-08-27). Elles n'existent pas sur un
            # ancien point de reprise : on retombe alors sur les scalaires du C++, ce
            # qui preserve la fidelite du clone.
            frost_profile, prof_gel_cm = self.frost(
                tmin, tmax, haut, state.frost_profile,
                pe["z11"], pe["z22"], pe["z33"],
                alpha=_pg.get("diff_gel"), fs=_pg.get("fs_neige"))
        else:
            frost_profile = state.frost_profile
            prof_gel_cm = torch.zeros_like(P)

        # 3. ETP × K_c (coefficient cultural NeRF par nœud) — corrige le biais
        # McGuinness et donne au NeRF un levier direct sur le volume (β).
        # K_c=1.0 par défaut si non fourni (chemins set_static hand-built).
        if etp_ext is not None:
            # module ET appris : demande en mm/j × K_c NeRF (correction de biais par nœud —
            # MOD16 biaise +15-30 % à l'est vs bilan P-Q, et sans multiplicateur le modèle
            # n'a AUCUN levier de volume : beta cloué 0.807, run gasp-etl 2026-07-21).
            etp = torch.clamp(etp_ext, min=0.0) * pe.get("K_c", 1.0)
        elif self.et_mode == "linacre":
            # couvert nival agrégé (mm SWE) + albédo neige pondéré par classe
            _couv = snow_new.get("couvert_nival_mm", haut * 1000.0)
            _albn = sum(ps[f"pct_{c}" if c != "decouver" else "pct_autres"]
                        * snow_new[f"albedo_{c}"] for c in DegreJourModifie.CLASSES)
            etp = self._etp(tmin_j, tmax_j, Rn, u2, ea, ps["lat"], doy_t,
                            couv=_couv, albn=_albn) * pe.get("K_c", 1.0)
        else:
            etp = self._etp(tmin_j, tmax_j, Rn, u2, ea, ps["lat"], doy_t) * pe.get("K_c", 1.0)

        # 4. ETR par couche (sur theta DÉBUT de pas). Phénologie interpolée en
        # TORCH (breakpoints cachés en tenseurs) — plus de np.interp ni de synchro
        # float(doy) par pas de temps. Résultats identiques (interp linéaire clampé).
        pheno = getattr(self, "_pheno_cache", None)
        if pheno is None:   # chemin set_static construit a la main, hors entrainement
            pheno = self._pheno_tensors(pe["classes"], P)
        d = doy_t.reshape(-1)[0]                  # jour julien scalaire (tenseur, sans synchro)
        etp_classes, roots, leaves = [], [], []
        for (pct, jbp_t, leaf_t, root_t) in pheno:
            etp_classes.append(etp * pct / 1000.0)
            roots.append(_interp1d(d, jbp_t, root_t).expand_as(P))
            leaves.append(_interp1d(d, jbp_t, leaf_t).expand_as(P))
        e1, e2, e3 = calcule_etr(state.theta1, state.theta2, state.theta3,
                                 etp_classes, roots, leaves, pe["thetacc"], pe["thetapf"],
                                 pe["alpha"], pe["z11"], pe["z22"], pe["z33"], pe["des"], pe["coef_assech"])

        # 5. bilan sol BV3C2 (porte gel via prof_gel_cm + couvert nival)
        couvert_mm = snow_new["couvert_nival_mm"]
        # Durée d'orage EFFECTIVE pondérée par la masse pluie vs fonte : seule la
        # PLUIE porte l'intensité convective DT_eff ; la fonte s'écoule sur 24 h.
        # Sans ça, un jour de fonte + averse courte fait passer toute la lame de
        # fonte dans le cap hortonien -> horton fictif massif au freshet (revue
        # 2026-07-01). apport = pluie (si pas de neige) ou fonte+pluie relâchées.
        if storm_hours is not None:
            melt_mm = torch.clamp(apport - pluie, min=0.0)
            w_rain = pluie / torch.clamp(pluie + melt_mm, min=1e-6)
            storm_hours = w_rain * storm_hours + (1.0 - w_rain) * 24.0
        ps_surf, ph, pb, rech, (t1, t2, t3), sdiag = self.soil(
            state.theta1, state.theta2, state.theta3, apport, etp, prof_gel_cm, couvert_mm, pso,
            etr1_mm=e1 * 1000.0, etr2_mm=e2 * 1000.0, etr3_mm=e3 * 1000.0, storm_hours=storm_hours)
        prod = ps_surf + ph + pb   # mm

        # 5b. Hydrogramme de VERSANT (cascade de Nash, fidèle Hydrotel, porté de
        # column.py). Lisse les composantes RAPIDES par étalement des temps de
        # parcours de versant AVANT le canal : surface POINTUE (k court, pic
        # préservé) + interflow LARGE (k long), baseflow direct. À coupler avec
        # pure_advection (canal cinématique). Sans lui, le Muskingum diffusif lisse
        # au mauvais endroit (pansement, cf 2026-06-27). forward sans le flag =
        # inchangé (fidélité 370.9 préservée).
        uh1n = uh2n = uh3n = uh4n = None
        if self.use_hillslope_uh:
            def _nash(inflow, s1, s2, log_k):
                if s1 is None: s1 = torch.zeros_like(inflow)
                if s2 is None: s2 = torch.zeros_like(inflow)
                k = torch.nn.functional.softplus(log_k) + 0.05      # jours
                a = 1.0 - torch.exp(-1.0 / k)                       # relâché/jour
                s1n = s1 + inflow; o1 = s1n * a; s1_new = s1n - o1
                s2n = s2 + o1;     o2 = s2n * a; s2_new = s2n - o2
                return o2, s1_new, s2_new
            surf_out, uh1n, uh2n = _nash(ps_surf, state.uh_s1, state.uh_s2, self.log_uh_k_surf)
            inter_out, uh3n, uh4n = _nash(ph, state.uh_s3, state.uh_s4, self.log_uh_k_inter)
            prod = surf_out + inter_out + pb

        # 6. milieu humide isolé (optionnel). production_surf/hypo/base.csv d'Hydrotel
        # est POST-MH (bv3c2.cpp l.838-895) : la prod totale passe dans le réservoir
        # SWAT puis prod = prodOld·(1−wetdrafr) + wetprod. Vectorisé sur tous les nœuds,
        # masqué (wmask) pour que les nœuds sans MH soient un no-op EXACT.
        wet_vol = state.wet_vol
        _etr_mh = _wvol_mm = None
        if self._static["wetland"] is not None:
            w = self._static["wetland"]
            apport_w = apport * w["wet_fr_area"]   # apport × fraction superficie wetland
            # clamp wet_vol>0 : évite 0^A=NaN dans le gradient (volume physique, pas
            # de masquage ; les vrais nœuds MH ont wet_vol>0, ce plancher est négligeable)
            vol_in = torch.clamp(state.wet_vol, min=1e-9)
            wet_vol_n, wsep, wflwi, wflwo, wprod, wev = calcul_milieu_humide_isole(
                vol_in, apport_w, etp, prod, w["hru_ha"], w["wet_dra_fr"],
                w["A"], w["B"], w["wetnvol"], w["wetmxvol"], w["wet_k"], w["c_ev"], w["c_prod"],
                conservatif=getattr(self, "mh_conservatif", True))
            prod_w = prod * (1.0 - w["wet_dra_fr"]) + wprod
            prod = torch.where(w["wmask"], prod_w, prod)
            wet_vol = torch.where(w["wmask"], wet_vol_n, state.wet_vol)
            # DEUX TERMES qui manquaient au diagnostic (2026-08-20). L'evaporation du
            # milieu humide est une perte atmospherique reelle, jamais declaree ; et le
            # volume du reservoir est un STOCK, jamais expose. Sans eux, un audit de
            # fermeture lit une fuite de 1.97 % de la precipitation, correlee a 0.48
            # avec la fraction de milieux humides. La physique ne change pas : on
            # publie ce qui existait deja.
            _ha10 = torch.clamp(w["hru_ha"] * 10.0, min=1e-9)
            _etr_mh = torch.where(w["wmask"], wev / _ha10, torch.zeros_like(prod))
            _wvol_mm = torch.where(w["wmask"], wet_vol / _ha10, torch.zeros_like(prod))

        new_state = HydrotelColumnState(t1, t2, t3, snow_new, frost_profile, wet_vol,
                                        uh1n, uh2n, uh3n, uh4n)
        etr_tot = (e1 + e2 + e3) * 1000.0
        diag = dict(apport=apport, etp=etp, etr1=e1 * 1000.0, etr2=e2 * 1000.0, etr3=e3 * 1000.0,
                    prof_gel_cm=prof_gel_cm, couvert_nival_mm=couvert_mm,
                    prod_surf=ps_surf, prod_hypo=ph, prod_base=pb,
                    # clés attendues par model.py / SimDiagnostics
                    etr=etr_tot, snowmelt=apport, lateral_mm=prod)
        # milieu humide : evaporation et STOCK, exposes le 2026-08-20 (ils existaient
        # dans la physique mais n'etaient rendus par aucune sortie, ce qui rendait le
        # bilan d'eau infermable)
        if _etr_mh is not None:
            diag["etr_mh_mm"] = _etr_mh
            diag["wet_vol_mm"] = _wvol_mm
        if subl_mm is not None:
            # sortie atmospherique : indispensable a la fermeture du bilan (ETL_BILAN)
            diag["subl_mm"] = subl_mm
        return prod, new_state, diag


# ── Cycles annuels par défaut (physio/ind_fol.def, pro_rac.def DELISLE) ──
_JBP = [1, 100, 135, 166, 180, 210, 244, 270, 274, 280, 365]
_LEAF = {"feuillus": [3, 4, 5, 5, 5, 5, 5, 5, 5, 5, 3], "ouverts": [1, 2, 3, 3, 3, 3, 3, 3, 3, 3, 1],
         "humides": [2, 3, 4, 4, 4, 4, 4, 4, 4, 4, 2], "conifers": [5] * 11,
         "mixtes": [3, 4, 5, 5, 5, 5, 5, 5, 5, 5, 3], "agri": [0, 0, 0, 2, 2, 2, 2, 2, 2, 0, 0],
         # végétation générique boréal QC (défaut quand l'occupation manque) :
         # LAI saisonnier modéré, racine ~1.2 m (cf pro_rac.def SLSO forêt = 1.26)
         "default": [2, 3, 4, 4, 4, 4, 4, 4, 4, 4, 2]}
_ROOT = {"feuillus": [1.5] * 11, "ouverts": [0.5] * 11, "humides": [0.75] * 11,
         "conifers": [1.0] * 11, "mixtes": [1.25] * 11,
         "agri": [0, 0, 0.3, 0.55, 0.7, 0.8, 0.8, 0.8, 0.3, 0, 0],
         "default": [1.2] * 11}


def build_static_params(n_nodes, lat, slope, orientation, texture, z, occupation,
                        device="cpu", dtype=torch.float64):
    """Construit les 3 dicts de params statiques par nœud à partir de descripteurs
    simples. SEAM Phase A : le NeRF/territorial fournira le sous-ensemble apprenable
    (texture/profondeurs/occupation régionalisés) à la place de ces scalaires.

    occupation : dict {classe: pourcentage} pour conifers/feuillus/mixtes/agri/
        urbain/routes/ouverts/eau/sols_nus/humides. eau→fse, urbain+routes→fsi,
        reste→fsa. Les classes ET = perméables non nulles (hors eau/imperm).
    texture : nom dans SOIL_TEXTURES. z = (z1,z2,z3) épaisseurs [m]."""
    T = lambda v: torch.full((n_nodes,), float(v), device=device, dtype=dtype)
    ce1, ce0 = init_ce(T(lat), T(slope), T(orientation))
    occ = {k: occupation.get(k, 0.0) for k in
           ("conifers", "feuillus", "mixtes", "agri", "urbain", "routes", "ouverts", "eau", "sols_nus", "humides")}
    pct_conif = occ["conifers"]
    pct_feu = occ["feuillus"] + occ["mixtes"]   # CLASSE INTEGRE FEUILLUS = feuillus + mixtes (DELISLE)
    p_snow = dict(lat=T(lat), ce1=ce1, ce0=ce0,
                  pct_conifers=T(pct_conif), pct_feuillus=T(pct_feu),
                  pct_autres=T(max(1.0 - pct_conif - pct_feu, 0.0)),
                  coeff_fonte_conifers=T(.012), coeff_fonte_feuillus=T(.014), coeff_fonte_decouver=T(.016),
                  seuil_fonte_conifers=T(0.0), seuil_fonte_feuillus=T(0.0), seuil_fonte_decouver=T(0.0),
                  taux_fonte_geo=T(0.5), densite_max=T(466.0), constante_tassement=T(0.1))

    fse = occ["eau"]
    fsi = occ["urbain"] + occ["routes"]
    fsa = max(1.0 - fse - fsi, 0.0)
    p_soil = make_params(texture, texture, texture, slope=slope, fsa=fsa, fse=fse, fsi=fsi,
                         krec=1e-6, cin=0.3, coef_recharge=0.0, device=device)
    for i in (1, 2, 3):
        p_soil[f"z{i}"] = T(z[i - 1])

    tx = SOIL_TEXTURES[texture]
    et_classes = []
    for c in ("conifers", "feuillus", "mixtes", "agri", "ouverts", "sols_nus", "humides"):
        pct = occ.get(c if c != "feuillus" else "feuillus", 0.0)
        if c in _LEAF and pct > 0:
            et_classes.append((pct, _JBP, _LEAF[c], _ROOT[c]))
    p_etr = dict(thetacc=T(tx["thetacc"]), thetapf=T(tx["thetapf"]), alpha=T(_TEXTURE_ALPHA[texture]),
                 des=T(0.6), coef_assech=T(1.0), z11=z[0], z22=z[1], z33=z[2], classes=et_classes)
    return p_snow, p_soil, p_etr


# alpha (assèchement ETR) par texture, proprietehydrolique.sol
_TEXTURE_ALPHA = {"sand": 10.0, "loamy_sand": 6.0, "sandy_loam": 4.5, "loam": 3.5,
                  "silt_loam": 3.0, "clay": 0.5, "peat": 6.0}
